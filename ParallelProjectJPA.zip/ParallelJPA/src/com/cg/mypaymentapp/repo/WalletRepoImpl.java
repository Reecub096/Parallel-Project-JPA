package com.cg.mypaymentapp.repo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.exception.WalletException;

public class WalletRepoImpl implements WalletRepo{
	
		//Map<String, Customer> customerMap;
		EntityManager manager;
	
		public WalletRepoImpl() {
				// TODO Auto-generated constructor stub
				//customerMap = DataStore.createCollection();
				EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPA-PU");
				manager = emf.createEntityManager();
			
		}
	
		@Override
		public Customer showBalance(String mobileno) {       // Function to Show Balance of customer
				// TODO Auto-generated method stub
				manager.getTransaction().begin();
				 Customer customer = manager.find(Customer.class, mobileno);
				manager.getTransaction().commit();
				return customer;
		}
	
		@Override
		public void updateBalance(String mobNo, Double amount) {            // Function to update the balance of customer in DataBase
				// TODO Auto-generated method stub
				manager.getTransaction().begin();
				Query sourceQuery = manager.createQuery("UPDATE Customer SET amount = :sourcebal where mobile = :sourcemobile");
				sourceQuery.setParameter("sourcebal", amount);
				sourceQuery.setParameter("sourcemobile", mobNo);
				manager.getTransaction().commit();
		
		}
	
		@Override
		public Customer createAccount(Customer customer) {               //Function to create account of customers  in DataBase
				// TODO Auto-generated method stub
				manager.getTransaction().begin();
				manager.persist(customer);
				manager.getTransaction().commit();
				return customer;
		}
	
		@Override
		public Customer findOne(String mobNo) {							//Function to retrieve details of customers
				// TODO Auto-generated method stub	
			manager.getTransaction().begin();
			 Customer customer = manager.find(Customer.class, mobNo);
			manager.getTransaction().commit();
				return customer;
		}

		@Override
		public boolean validateAccount(String mobNo) throws WalletException {    			//Function to validate Account Details of customers
			
			manager.getTransaction().begin();
			Customer customer = manager.find(Customer.class, mobNo);
			manager.getTransaction().commit();
			if(customer == null)
				return false;
				return true;
		}
		

}
