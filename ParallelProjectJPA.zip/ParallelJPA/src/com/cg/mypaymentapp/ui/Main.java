package com.cg.mypaymentapp.ui;

import java.util.Scanner;

import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.service.WalletService;
import com.cg.mypaymentapp.service.WalletServiceImpl;

public class Main {
	
	@SuppressWarnings("resource")
	public static void main(String[] args) {
			// TODO Auto-generated method stub
		
		WalletService service = new WalletServiceImpl();
		Scanner sc = new Scanner(System.in);
		String custName;
		double amount = 0;
		String mobNum;
		Customer customer;
		int ch;
		do {
				System.out.println("1. Create Customer Acoount ");
				System.out.println("2. Balance show ");
				System.out.println("3. Fund transfer ");
				System.out.println("4. Withdraw ");
				System.out.println("5. Deposit ");
				System.out.println("6. Exit ");
				System.out.print("Enter your choice : ");
				ch = sc.nextInt();
				switch (ch) {
				
				case 1: // create account 
					do{//getting user details
							do{
									System.out.print("Enter customer name : ");
									custName = sc.next();
									if(service.validateName(custName))
											break;
								}while(true);
						
								do{System.out.print("Enter mobile no. : ");
										mobNum = sc.next();
										if(service.validateMoileNo(mobNum))
											break;
									}while(true);
						
									do{
												System.out.print("Enter initial amount : (Amount > 0) ");
												amount = sc.nextDouble();
												if(service.validateAmount(amount))
													break;
									}while(true);
						
					   customer = new Customer();
						customer.setName(custName);
						customer.setMobileNo(mobNum);
						customer.setAmount(amount);
						service.createAccount(customer);
						System.out.println(" Account Created !! ");
						break;
					}while(true);
					break;
				
				case 2 : // Balance Show
					
						System.out.print(" Enter the customer mobile number : ");
						mobNum = sc.next();
						if(service.validateMoileNo(mobNum) && (service.validateAccount(mobNum)))
							service.showBalance(mobNum);
						else 
							System.out.println("Mobile Account does not exist !!!");
						break;

					
				case 3 : // Fund Transfer
							String mob1;
							String mob2;
						do {	
								do{
										System.out.print(" Enter the Sender Phone Number : ");
										mob1 = sc.next();
										System.out.print("Enter the Receiver Phone Number : ");
										mob2 = sc.next();
									if(service.validateMoileNo(mob1) && service.validateAccount(mob1)){
										if(service.validateMoileNo(mob2) && service.validateAccount(mob2))
											break;
											else
											{
												System.out.println("Receiver Account does not exist");
											}
										}
									else {
										System.out.println("Sender Account does not exist ");
									}
								}while(true);
								do {
										System.out.print(" Enter the amount to be transferred : ");
										amount = sc.nextDouble();
										if(service.validateAmount(amount))
											break;
										else
											System.out.println("Amount not entered properly !!! Enter below 100000000 ");
								}while(true);
						service.fundTransfer(mob1, mob2, amount);
						break;
						}while(true);
					break;
						
				case 4 : // Withdraw Function
					
					do{
						System.out.println("Enter your mobile number : ");
						mobNum = sc.next();
						
						System.out.println("Enter the amount you want to withdraw : ");
						amount = sc.nextDouble();
						if(service.validateMoileNo(mobNum) && service.validateAmount(amount)){
							if(service.validateAccount(mobNum))
								break;
							else
							{
								System.out.println("Mobile Account does not exist");
							}
						}
						
					}while(true);
					
					service.withdrawAmount(mobNum, amount);
					
				break;
						
				case 5 : // Deposit Function
						System.out.println(" Enter the Customer mobile number : ");
						mobNum = sc.next();
						System.out.println(" Enter the amount to be deposited : ");
						amount = sc.nextDouble();
						if(service.validateMoileNo(mobNum) && service.validateAmount(amount)){
							if(service.validateAccount(mobNum))
								break;
							else
							{
								System.out.println("Mobile Account does not exist");
							}
						}
						service.depositAmount(mobNum, amount);
						break;
				}
		}while(ch != 6);
		System.out.println("Program Ended successfully !!!! ");
	}

}
