package com.cg.mypaymentapp.test;

import org.junit.Assert;
import org.junit.Test;

import com.cg.mypaymentapp.exception.WalletException;
import com.cg.mypaymentapp.service.WalletService;
import com.cg.mypaymentapp.service.WalletServiceImpl;

public class TestClass {

   /* @Test(expected=WalletException.class)
    public void test_ValidateName_null() throws WalletException{
        WalletService service=new WalletServiceImpl();
        service.validateName(null);
    }*/
    
    @Test
    public void test_validateName_v1() throws WalletException{
    
        String name="Aete121";
        WalletService service=new WalletServiceImpl();
        boolean result= service.validateName(name);
        Assert.assertEquals(false,result);
    }
    @Test
    public void test_validateName_v2() throws WalletException{
    
        String name="Amita";
        WalletService service=new WalletServiceImpl();
        boolean result= service.validateName(name);
        Assert.assertEquals(true,result);
    }
    @Test
    public void test_validateName_v3() throws WalletException{
    
        String name="amita";
        WalletService service=new WalletServiceImpl();
        boolean result= service.validateName(name);
        Assert.assertEquals(false,result);
    }
    
    
    @Test
    public void test_validateMobNo_v1() throws WalletException{
    
        String mobNo="ABCD91828288";
        WalletService service=new WalletServiceImpl();
        boolean result= service.validateMoileNo(mobNo);
        Assert.assertEquals(false,result);
    }
    @Test
    public void test_validateMobNo_v2() throws WalletException{
    
        String mobNo="9922974725";
        WalletService service=new WalletServiceImpl();
        boolean result= service.validateMoileNo(mobNo);
        Assert.assertEquals(true,result);
    }
    @Test
    public void test_validateMobNo_v3() throws WalletException{
    
        String mobNo="992297";
        WalletService service=new WalletServiceImpl();
        boolean result= service.validateMoileNo(mobNo);
        Assert.assertEquals(false,result);
    }
   
    
}
